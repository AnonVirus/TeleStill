# Stealer for Telegram Desktop

Video: https://www.youtube.com/watch?v=fdwNm33-YJk

to steal the session of your application. forever!

